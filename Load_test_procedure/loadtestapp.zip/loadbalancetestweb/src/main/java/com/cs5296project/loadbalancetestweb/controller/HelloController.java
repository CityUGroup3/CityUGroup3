package com.cs5296project.loadbalancetestweb.controller;

import java.net.InetAddress;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloController {
	
	@Autowired
	Environment environment;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String hello(@RequestParam(value = "name", defaultValue = "World") String name, ModelMap model) {
		String port = environment.getProperty("local.server.port");
		String ip = "";
		try {
			ip =  InetAddress.getLocalHost().getHostAddress();
		}catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("location", ip+":"+port);
		
		return "test";
	}

}
