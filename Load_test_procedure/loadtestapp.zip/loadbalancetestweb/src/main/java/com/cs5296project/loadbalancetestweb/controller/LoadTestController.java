package com.cs5296project.loadbalancetestweb.controller;

import java.net.InetAddress;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoadTestController {
	
	@Autowired
	Environment environment;
	
	@RequestMapping(value = "/loadtest1", method = RequestMethod.GET)
	public String loadtest1(@RequestParam(value = "name", defaultValue = "World") String name, ModelMap model) {
		
		model.addAttribute("message", "Load Test Page 1 - 1MB");
		String port = environment.getProperty("local.server.port");
		String ip = "";
		try {
			ip =  InetAddress.getLocalHost().getHostAddress();
		}catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("location", ip+":"+port);
		
		return "loadtestpage";
	}
	
	@RequestMapping(value = "/loadtest2", method = RequestMethod.GET)
	public String loadtest2(@RequestParam(value = "name", defaultValue = "World") String name, ModelMap model) {
		
		model.addAttribute("message", "Load Test Page 2 - 3MB");
		String port = environment.getProperty("local.server.port");
		String ip = "";
		try {
			ip =  InetAddress.getLocalHost().getHostAddress();
		}catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("location", ip+":"+port);
		
		return "loadtestpage2";
	}
	
	@RequestMapping(value = "/loadtest3", method = RequestMethod.GET)
	public String loadtest3(@RequestParam(value = "name", defaultValue = "World") String name, ModelMap model) {
		
		model.addAttribute("message", "Load Test Page 3 - 5MB");
		String port = environment.getProperty("local.server.port");
		String ip = "";
		try {
			ip =  InetAddress.getLocalHost().getHostAddress();
		}catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("location", ip+":"+port);
		
		return "loadtestpage3";
	}

}
