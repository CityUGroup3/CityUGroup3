package com.cs5296project.loadbalancetestweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoadbalancetestwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
